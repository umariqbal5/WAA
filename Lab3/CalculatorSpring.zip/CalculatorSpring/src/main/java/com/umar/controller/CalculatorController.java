package com.umar.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class CalculatorController {

    @RequestMapping("/")
    public String Welcome(){
        return "welcome";
    }

    @RequestMapping("/calc")
    public String Calc(Model model , @RequestParam String add1, @RequestParam String add2, @RequestParam String mult1, @RequestParam String mult2){

        Integer mult=0;
        Integer sum=0;
        if(!add1.equalsIgnoreCase("") && !add2.equalsIgnoreCase(""))
                sum= Integer.parseInt(add1) + Integer.parseInt(add2);
        if(!mult1.equalsIgnoreCase("") && !mult2.equalsIgnoreCase(""))
            mult = Integer.parseInt(mult1) + Integer.parseInt(mult2);

        model.addAttribute("add1", add1);
        model.addAttribute("add2", add2);
        model.addAttribute("sum", sum);

        model.addAttribute("mult1", mult1);
        model.addAttribute("mult2", mult2);
        model.addAttribute("mult", mult);
        return "welcome";
    }
}
